#!/bin/bash
#SBATCH --account=k1288
#SBATCH --job-name=2decomp
#SBATCH --output=2decomp.out
#SBATCH --error=2decomp.err
#SBATCH --nodes=256
#SBATCH --time=00:30:00


srun -n 8192 ./timing
